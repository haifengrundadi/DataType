#include "linearlist.h"
template<class T>
LinearList<T>::LinearList()
{
    //ctor
}
