#ifndef TEST_H
#define TEST_H


class Test
{
    public:
        Test();
        virtual ~Test();
    protected:
    private:
};

#endif // TEST_H
